// flouciPayment_isInit = true;
// $(document).ready(function () {
//     if (!flouciPayment_isInit && $('section#checkout-payment-step').hasClass('js-current-step')) {
//         initFlouciOfficialPay();
//     }
// });
//
// function initFlouciOfficialPay() {
//     flouciPayment_isInit = true;
//     gettingFormFromLib();
//     console.log("heyy");
//     var prestaSubmitButton = document.getElementById('payment-confirmation');
//     prestaSubmitButton.addEventListener('click', function (event) {
//         event.preventDefault();
//         event.stopPropagation();
//         flouciButton.click();
//         console.log("event captured successfully");
//
//     })
// function gettingFormFromLib(){
//     var flouciButton = document.getElementById("flouci-button-id");
//     flouciButton.style.display = 'none';
//     flouciButton.click();
//     document.getElementById("background").remove();
// }
// }