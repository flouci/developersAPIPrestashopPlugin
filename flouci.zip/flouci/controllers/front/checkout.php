<?php

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class FlouciCheckoutModuleFrontController extends ModuleFrontController
{
    private $verifyURL = "https://datastaging.flouci.com/api/developer/verify";

    public function postProcess()
    {

        parent::postProcess();
        $cart = $this->context->cart;
        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }
        //init
        $redirect_url_error = 'index.php?controller=order&step=1&flouci-payment-error=';

        $appPubKey = Tools::getValue("app_pub_key");
        $flouciOTP = "F-".Tools::getValue("flouci-otp");
        $result = $this->verifyTransaction($flouciOTP, $appPubKey);

        if ($result->code == 0) {

            $validateLink = $this->context->link->getModuleLink($this->module->name,'validate',array(
                "id" => $result->result->id,
                "flouci-otp" =>$flouciOTP,
                "app_pub_key" => $appPubKey
            ),false);
            Tools::redirect($validateLink);
        } else {
            $link_redirect = __PS_BASE_URI__ . $redirect_url_error.$result->code;
            Tools::redirect($link_redirect);
        }


    }

    protected function verifyTransaction($otp, $appPub)
    {


        $req = [
            "app" => $appPub,
            "code" => $otp
        ];
        $client = new Client([
            'timeout' => 2.0,
        ]);
        echo "<script>console.log(".json_encode($req).")</script>";

        try{
        $res = $client->post($this->verifyURL, [
                "json" => $req,
                'verify' => false,
            ]
        );}
    catch(RequestException $e){
        $resultat =json_decode($e->getResponse()->getBody());
        if(!isset($resultat->code))
            $resultat->code = 18;
        return $resultat;
    }
        return json_decode($res->getBody());
    }
}