<?php
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class FlouciValidateModuleFrontController extends ModuleFrontController
{

    private $submitURL = "https://developers.flouci.com/api/accept";

    public function postProcess()
    {        parent::postProcess();
        $secretAppToken = Configuration::get("FLOUCI_APP_SECRET_KEY");

        $appPubKey = Tools::getValue("app_pub_key");
        $flouciOTP = Tools::getValue("flouci-otp");
        $txId = Tools::getValue("id");
        $redirect_url_error = 'index.php?controller=order&step=1&flouci-payment-error=';
        $order_confirmation_url = 'index.php?controller=order-confirmation&';
        $cart = $this->context->cart;
        $total = (float)$cart->getOrderTotal(true, Cart::BOTH) * 1000;
        $customer = new Customer($cart->id_customer);
        $userSecureKey = $customer->secure_key;
        $response = $this->acceptPayment($appPubKey,$secretAppToken,$flouciOTP,$txId,$total);
        $extraVars = array(
            "transactionId"=>$txId
        );



        if($response->code == 0){
            $this->module->validateOrder($cart->id,
                Configuration::get('PS_OS_PAYMENT'),
                $total,
                $this->module->displayName,
                "Success",
                $extraVars,
                $cart->id_currency,
                false,
                $userSecureKey);
            $link_redirect = __PS_BASE_URI__ . $order_confirmation_url . 'id_cart=' . $cart->id
                . '&id_module='
                . $this->module->id
                . '&id_order='
                . $this->module->currentOrder
                . '&key='
                . $userSecureKey;
        }
        else{
            $link_redirect = $redirect_url_error.$response->code."101";
        }


        Tools::redirect($link_redirect);
    }

    private function acceptPayment($appPublic, $appSecret, $otp, $txId,$amount)
    {
        $req = [
            "app_secret" => $appSecret,
            "app_token" => $appPublic,
            "payment_id" => $txId,
            "flouci_otp" => $otp,
            "amount" => $amount
        ];
        $client = new Client([
            // You can set any number of default request options.
            'timeout' => 12.0,
        ]);

        try{
            $res = $client->post($this->submitURL, [
                    "json" => $req,
                    'verify' => false,
                ]
            );
            return json_decode($res->getBody());
        }
        catch(RequestException $e){
            $resultat =json_decode($e->getResponse()->getBody());
            if(!isset($resultat->code))
                $resultat->code = 18;
            return $resultat;
        }

    }
}
