# Flouci Prestashop Plugin
### How To Bundle

1 - The project needs to be in a folder called flouci
2 - Create a zip with the folder inside