<?php
/**
 * Created by IntelliJ IDEA.
 * User: GASTLEE
 * Date: 7/8/2019
 * Time: 9:53 AM
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class Flouci extends PaymentModule
{

    public function __construct($name = null, Context $context = null)
    {
        $this->name = "flouci";
        $this->tab = "payments_gateways";
        $this->version = "1.0.0";
        $this->author = "Kaoun";
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            "min" => '1.7',
            "max" => _PS_VERSION_
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l("Flouci payment");
        $this->description = $this->l("this is the description for the flouci payment module");
        $this->confirmUninstall = $this->l("Are you sure you want to uninstall Flouci module?");

        if (!Configuration::get("FLOUCI_MODULE_NAME")) {
            $this->warning = $this->l("No name provided.");
        }

    }

    public function install()
    {
        if (!parent::install()
            || !$this->registerHook('paymentOptions')
            || !$this->registerHook('header')
            || !$this->registerHook('paymentReturn')
            || !$this->registerHook('displayPaymentTop')
        )
            return false;
        Configuration::updateValue('FLOUCI_IS_LIVE_MODE', false);
        return true;
    }

    public function uninstall()
    {
        if (!Configuration::deleteByName("FLOUCI_APP_PUBLIC_KEY") ||
            !Configuration::deleteByName('FLOUCI_APP_SECRET_KEY') ||
            !Configuration::deleteByName('FLOUCI_IS_LIVE_MODE') ||
            !parent::uninstall()
        ) {
            return false;
        }
        return true;
    }

    public function hookPaymentOptions($params)
    {
        if ($this->context->currency->iso_code != "TND")
            return [];


        $amount = $this->context->cart->getOrderTotal(true,Cart::BOTH) * 1000;

        $pub_key = Configuration::get("FLOUCI_APP_PUBLIC_KEY");
        $isTest = !Configuration::get("FLOUCI_IS_LIVE_MODE");
        $payment_options = array();
        $iFrameOption = new PaymentOption();
        $iFrameOption->setCallToActionText($this->l("Pay with flouci"))
            ->setForm($this->generateFlouciForm($amount, $pub_key,$isTest))
            ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/Pay-with-flouci-banner_en_small.png'));
        $payment_options[] = $iFrameOption;
        return $payment_options;
    }

    public function hookHeader()
    {
        $this->context->controller->addJquery();
        $this->context->controller->registerJavascript($this->name . '-floucipaymentjs', 'modules/' . $this->name . '/views/js/paymentfront.js');
    }

    public function hookDisplayPaymentTop($params){
        if (!$this->active) {
            return null;
        }
        $error = false;
        $error_message = "";
        $flouci_error = Tools::getValue('flouci-payment-error');
        if (isset($flouci_error)
            && $flouci_error == 1
        ) {
            $error = true;
            $error_message = $this->l("Mauvais code, veuillez réessayer");
        } elseif (isset($flouci_error)
            && $flouci_error == 2
        ){
            $error = true;
            $error_message = $this->l("Veuillez vérifier votre solde et réessayer plus tard");
        } elseif (isset($flouci_error)
            && $flouci_error == 18
        ){
            $error = true;
            $error_message = $this->l("Le serveur de Flouci est en panne, veuillez réessayer dans quelques minutes.");
        }
        $this->context->smarty->assign(array(
            'error'=>$error,
            'error_message' => $error_message
        ));
        return $this->context->smarty->fetch('module:' . $this->name . '/views/templates/hook/payment-error.tpl',null,null,null);


    }

    public function hookPaymentReturn($params){
        if (!$this->active) {
            return null;
        }
        $order_id = Tools::getValue('id_order');
        $order = new Order($order_id);
        $state = null;
        if (isset($order->current_state)
            && $order->current_state == Configuration::get('PS_OS_PAYMENT')
        ) {
            $state = 'Success';
        } elseif (isset($order->current_state)
            && $order->current_state == Configuration::get('PS_OS_ERROR')
        ){
            $state = 'Error';
        }
        $this->smarty->assign('state', $state);
        $total_paid = number_format($order->total_paid, 3, ',', '');
        $context = array('totalPaid' => $total_paid);
        if (isset($order->reference)) {
            $context['reference'] = $order->reference;
        }
        $this->smarty->assign($context);
        return $this->display(__FILE__, 'confirmation.tpl');

    }
    protected function generateFlouciForm($amount, $app_public,$isTest)
    {if($isTest==1){
        $isTest="true";
    }
    else{
        $isTest="false";
    }

        $this->context->smarty->assign(
            array('actionurl' => $this->context->link->getModuleLink($this->name, 'checkout', array(), false),
                'amount' => $amount,
                'pubkey' => $app_public,
                'isTest' => $isTest
            ));
        return $this->context->smarty->fetch('module:' . $this->name . '/views/templates/front/checkout.tpl');
    }

    public function getContent()
    {

        if (((bool)Tools::isSubmit('submitFlouciModule')) == true) {
            $this->postProcess();
        }

        $this->context->smarty->assign('module_dir', $this->_path);

        $output = $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');

        return $output.$this->renderForm();
    }
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitFlouciModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs',
                ),

                'input' => array(
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Live mode'),
                        'name' => 'FLOUCI_IS_LIVE_MODE',
                        'is_bool' => true,
                        'desc' => $this->l('Use this module in live mode'),
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled')
                            )

                        ),
                    ),
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-cog"></i>',
                        'desc' => $this->l('Enter a valid public key'),
                        'name' => 'FLOUCI_APP_PUBLIC_KEY',
                        'label' => $this->l('Public token'),
                        'required' => true
                    ),
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-key"></i>',
                        'name' => 'FLOUCI_APP_SECRET_KEY',
                        'desc' => $this->l('Enter the corresponding private key'),
                        'label' => $this->l('Private token'),
                        'required' => true
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    protected function getConfigFormValues()
    {
        return array(
            'FLOUCI_APP_PUBLIC_KEY' => Configuration::get('FLOUCI_APP_PUBLIC_KEY', null),
            'FLOUCI_APP_SECRET_KEY' => Configuration::get('FLOUCI_APP_SECRET_KEY', null),
            'FLOUCI_IS_LIVE_MODE' => Configuration::get('FLOUCI_IS_LIVE_MODE', null),
        );
    }
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }
}
